These are the files for building a RFO-BASIC project in Eclipse.
